const CACHE = 'stary-jicin-v1';
const ASSETS = ['/', '/index.html', '/manifest.json', '/ikona.png'];

self.addEventListener('install', e => {
  e.waitUntil(caches.open(CACHE).then(c => c.addAll(ASSETS)));
});

self.addEventListener('fetch', e => {
  e.respondWith(
    fetch(e.request).catch(() => caches.match(e.request))
  );
});
